import { useState } from 'react'
import  PageHeader  from '../components/layout/PageHeader-model'
import { TabContainer, Tab } from '../components/ui/tab-container'
import { Button } from '../components/ui/button-model'
import { Calendar, Download } from 'lucide-react'
import { OverviewTab } from '../components/tabs/OverviewTab'
import { XAITab } from '../components/tabs/XAITab'
import { OperationalTab } from '../components/tabs/OperationalTab'
import { ThresholdTuningTab } from '../components/tabs/ThresholdTuningTab'
import  LogsTab  from '../components/tabs/LogsTab'
import '../App.css'

const ModelManagement = () => {
  const [activeTab, setActiveTab] = useState('overview')

  const tabs = [
    { id: 'overview', label: 'Overview', icon: '📊' },
    { id: 'xai', label: 'XAI', icon: '🔬' },
    { id: 'operational', label: 'Operational', icon: '⚙️' },
    { id: 'threshold-tuning', label: 'Threshold Tuning', icon: '🎛️' },
    { id: 'logs', label: 'Logs', icon: '📋' },
  ]

  const renderTabContent = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewTab />
      case 'xai':
        return <XAITab />
      case 'operational':
        return <OperationalTab />
      case 'threshold-tuning':
        return <ThresholdTuningTab />
      case 'logs':
        return <LogsTab />
      default:
        return <OverviewTab />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      
      <div className="p-6 max-w-7xl mx-auto">
        {/* Main Page Tabs */}
        <TabContainer className="mb-6">
          {tabs.map((tab) => (
            <Tab
              key={tab.id}
              active={activeTab === tab.id}
              onClick={() => setActiveTab(tab.id)}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.label}
            </Tab>
          ))}
        </TabContainer>

        {/* Page Header */}
        <PageHeader
          title="Model Management"
          subtitle="Comprehensive monitoring and management of fraud detection models"
          actions={
            <>
              <Button variant="outline">
                <Calendar className="h-4 w-4" />
                Select Date Range
              </Button>
              <Button variant="outline">
                <Download className="h-4 w-4" />
                Export Report
              </Button>
            </>
          }
        />

        {/* Tab Content */}
        <div className="mt-6">
          {renderTabContent()}
        </div>
      </div>
    </div>
  )
}

export default ModelManagement

