import React from 'react';
import Dashboard from '../components/ui/Dashboard';
import Card from '../components/ui/Card';
import ChartBox from '../components/ui/ChartBox';
import FraudVolumeChart from '../components/charts/FraudVolumeChart';
import FraudTypesChart from '../components/charts/FraudTypesChart';
import MetricGrid from '../components/ui/MetricGrid';
import MetricItem from '../components/ui/MetricItem';
import ContentBox from '../components/ui/ContentBox';
import InfoBox from '../components/ui/InfoBox';
import DataTable from '../components/ui/DataTable';
import DataTableContainer from '../components/ui/DataTableContainer';

// Mock data for the Technology page
const techAdoptionData = {
  labels: ['AI/ML', 'Biometrics', 'Behavioral Analytics', 'Device Intelligence', 'Blockchain'],
  datasets: [
    {
      label: 'Industry Adoption (%)',
      data: [68, 52, 75, 82, 24],
      backgroundColor: 'rgba(243, 156, 18, 0.7)',
      borderColor: 'rgba(243, 156, 18, 1)',
      borderWidth: 1
    },
    {
      label: 'Our Implementation (%)',
      data: [85, 70, 90, 75, 30],
      backgroundColor: 'rgba(93, 142, 255, 0.7)',
      borderColor: 'rgba(93, 142, 255, 1)',
      borderWidth: 1
    }
  ]
};

const mlPerformanceData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
  datasets: [
    {
      label: 'Accuracy (%)',
      data: [91.2, 91.5, 92.1, 92.8, 93.2, 93.5, 93.8, 94.2, 94.5, 94.8, 95.1, 95.4],
      borderColor: '#5D8EFF',
      backgroundColor: 'rgba(93, 142, 255, 0.1)',
      fill: true,
      tension: 0.4,
      yAxisID: 'y'
    },
    {
      label: 'False Positives (%)',
      data: [8.8, 8.5, 7.9, 7.2, 6.8, 6.5, 6.2, 5.8, 5.5, 5.2, 4.9, 4.6],
      borderColor: '#FF5E7D',
      backgroundColor: 'rgba(255, 94, 125, 0.1)',
      fill: true,
      tension: 0.4,
      yAxisID: 'y1'
    }
  ]
};

const techInvestmentData = {
  labels: ['AI/ML Models', 'Biometric Auth', 'Behavioral Analytics', 'Device Intelligence', 'Blockchain'],
  datasets: [
    {
      label: 'Current Investment ($K)',
      data: [850, 420, 650, 380, 150],
      backgroundColor: 'rgba(93, 142, 255, 0.7)',
      borderColor: 'rgba(93, 142, 255, 1)',
      borderWidth: 1
    },
    {
      label: 'Planned Investment ($K)',
      data: [1200, 650, 800, 450, 300],
      backgroundColor: 'rgba(123, 108, 255, 0.7)',
      borderColor: 'rgba(123, 108, 255, 1)',
      borderWidth: 1
    }
  ]
};

const emergingTechData = {
  labels: ['Quantum-resistant Crypto', 'Federated Learning', 'Zero-knowledge Proofs', 'Continuous Auth', 'Synthetic Data'],
  datasets: [
    {
      label: 'Potential Impact (1-10)',
      data: [8.5, 7.8, 9.2, 8.7, 7.5],
      backgroundColor: [
        'rgba(93, 142, 255, 0.7)',
        'rgba(123, 108, 255, 0.7)',
        'rgba(46, 204, 113, 0.7)',
        'rgba(243, 156, 18, 0.7)',
        'rgba(155, 89, 182, 0.7)'
      ],
      borderColor: [
        'rgba(93, 142, 255, 1)',
        'rgba(123, 108, 255, 1)',
        'rgba(46, 204, 113, 1)',
        'rgba(243, 156, 18, 1)',
        'rgba(155, 89, 182, 1)'
      ],
      borderWidth: 1
    }
  ]
};

const TechnologyPage = () => {
  return (
    <div className="page-content">
      <Dashboard>
        {/* Technology Adoption */}
        <Card 
          title="Technology Adoption" 
          icon="microchip" 
          span={8}
          actions={[
            { icon: 'expand', onClick: () => console.log('Expand clicked') }
          ]}
          expandable={true}
        >
          <ChartBox id="techAdoptionChart">
            <FraudVolumeChart 
              data={techAdoptionData}
              options={{
                indexAxis: 'y',
                scales: {
                  x: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                      display: true,
                      text: 'Adoption (%)'
                    }
                  }
                }
              }}
            />
          </ChartBox>
          
          <ContentBox 
            variant="info" 
            title="Technology Leadership" 
            icon="trophy" 
            padding="medium"
            className="mt-4"
          >
            Our organization leads the industry in AI/ML and Behavioral Analytics adoption, with implementation rates 17% and 15% above industry averages respectively.
          </ContentBox>
        </Card>
        
        {/* ML Model Performance */}
        <Card 
          title="ML Model Performance" 
          icon="brain" 
          span={4}
        >
          <MetricGrid>
            <MetricItem 
              label="Current Accuracy"
              icon="bullseye"
              value="95.4%"
              comparison="4.2% improvement"
              trend="up"
            />
            <MetricItem 
              label="False Positives"
              icon="times-circle"
              value="4.6%"
              comparison="4.2% reduction"
              trend="down"
            />
          </MetricGrid>
          
          <ChartBox id="mlPerformanceChart" height="small">
            <FraudVolumeChart 
              data={mlPerformanceData}
              options={{
                scales: {
                  y: {
                    beginAtZero: false,
                    min: 90,
                    max: 100,
                    title: {
                      display: true,
                      text: 'Accuracy (%)'
                    }
                  },
                  y1: {
                    beginAtZero: true,
                    max: 10,
                    position: 'right',
                    grid: {
                      drawOnChartArea: false
                    },
                    title: {
                      display: true,
                      text: 'False Positives (%)'
                    }
                  }
                }
              }}
            />
          </ChartBox>
        </Card>
        
        {/* Technology Investment */}
        <Card 
          title="Technology Investment" 
          icon="money-bill-wave" 
          span={6}
        >
          <ChartBox id="techInvestmentChart">
            <FraudVolumeChart 
              data={techInvestmentData}
              options={{
                indexAxis: 'y'
              }}
            />
          </ChartBox>
          
          <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
            <InfoBox 
              type="success"
              title="ROI Leader"
              icon="chart-line"
            >
              AI/ML models deliver 320% ROI, highest among all fraud prevention technologies.
            </InfoBox>
            
            <InfoBox 
              type="info"
              title="Growth Focus"
              icon="rocket"
            >
              Planned 100% increase in blockchain investment for cross-border payment verification.
            </InfoBox>
          </div>
        </Card>
        
        {/* Emerging Technologies */}
        <Card 
          title="Emerging Technologies" 
          icon="lightbulb" 
          span={6}
        >
          <ChartBox id="emergingTechChart">
            <FraudTypesChart 
              data={emergingTechData}
              options={{
                plugins: {
                  legend: {
                    display: false
                  }
                }
              }}
            />
          </ChartBox>
          
          <DataTableContainer title="Implementation Roadmap">
            <DataTable 
              headers={[
                { id: 'technology', label: 'Technology' },
                { id: 'timeline', label: 'Timeline' },
                { id: 'priority', label: 'Priority' }
              ]}
              data={[
                { technology: 'Zero-knowledge Proofs', timeline: 'Q3 2025', priority: 'High' },
                { technology: 'Continuous Authentication', timeline: 'Q4 2025', priority: 'High' },
                { technology: 'Quantum-resistant Crypto', timeline: 'Q1 2026', priority: 'Medium' },
                { technology: 'Federated Learning', timeline: 'Q2 2026', priority: 'Medium' },
                { technology: 'Synthetic Data', timeline: 'Q3 2026', priority: 'Low' }
              ]}
              sortable={true}
            />
          </DataTableContainer>
        </Card>
      </Dashboard>
    </div>
  );
};

export default TechnologyPage;
