import React from 'react';

function FraudReportsPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Fraud Reports</h1>
      <p>This is a placeholder for the Fraud Reports page.</p>
    </div>
  );
}

export default FraudReportsPage;