import React from 'react';
import PageHeader from '../components/layout/PageHeader';
import { TabContainer, TabPanel } from '../components/ui/TabContainer-case';
import CaseView from './CaseView';
import CaseOverview from './CaseOverview';

const Cases = () => {
  return (
    <div className="p-6 max-w-7xl mx-auto">
      <PageHeader 
        title="Cases Management" 
        description="Manage fraud detection rules and review case overrules"
      />
      
      <TabContainer defaultTab={0}>
        <TabPanel label="Case View">
          <CaseView />
        </TabPanel>
        <TabPanel label="Overview">
          <CaseOverview />
        </TabPanel>
      </TabContainer>
    </div>
  );
};

export default Cases;

