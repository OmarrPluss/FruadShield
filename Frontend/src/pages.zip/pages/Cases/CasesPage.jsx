import React, { useState, useRef } from 'react';
import { FaIcon } from '@/components/ui/FaIcon';
import TabContainer from '@/components/layouts/TabContainer';
import CaseOverview from './CaseOverview';
import CaseView from './CaseView';

const CasesPage = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const contentRef = useRef();

  const tabs = [
    { id: 'overview', name: 'Case Overview', icon: 'clipboard-list' },
    { id: 'view', name: 'Case View', icon: 'table' }
  ];

  return (
    <div className="bg-gray-900 text-gray-100 min-h-screen">
      <div className="p-6 max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center">
              <FaIcon icon="user-shield" className="mr-2 text-blue-400" />
              Fraud Case Management
            </h1>
            <div className="text-gray-400 text-sm">
              Last updated: {new Date().toLocaleString()}
            </div>
          </div>
        </div>

        <TabContainer 
          tabs={tabs} 
          activeTab={activeTab} 
          onTabChange={setActiveTab}
          className="border-b border-gray-700"
        />

        <div ref={contentRef} className="mt-4">
          {activeTab === 'overview' && <CaseOverview />}
          {activeTab === 'view' && <CaseView />}
        </div>
      </div>
    </div>
  );
};

export default CasesPage;
