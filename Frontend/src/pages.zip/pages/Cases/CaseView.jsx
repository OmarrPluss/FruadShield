import React, { useState } from 'react';
import { FaIcon } from "../../components/ui/FaIcon";
import Card from "../../components/ui/Card";
import Button from "../../components/ui/Button";

const CaseView = () => {
  // Original HTML data
  const [rules, setRules] = useState([
    {
      id: "R001",
      name: "High Value Txn - New Device",
      logic: "Transaction.Amount > 5000 AND User.IsNewDevice = TRUE AND Transaction.Country != User.HomeCountry",
      action: "BLOCK",
      priority: "high",
      status: "active",
      modified: "2024-05-10"
    },
    // ... other rules from HTML
  ]);

  const [showModal, setShowModal] = useState(false);
  const [currentRule, setCurrentRule] = useState(null);

  // API simulation
  const saveRule = async (rule) => {
    // Replace with actual API call:
    /*
    const response = await fetch('/api/rules', {
      method: rule.id ? 'PUT' : 'POST',
      body: JSON.stringify(rule)
    });
    return await response.json();
    */
    return new Promise(resolve => {
      setTimeout(() => {
        if (!rule.id) {
          rule.id = `R${Math.floor(Math.random() * 1000)}`;
          setRules([rule, ...rules]);
        } else {
          setRules(rules.map(r => r.id === rule.id ? rule : r));
        }
        resolve(rule);
      }, 300);
    });
  };

  return (
    <>
      <Card className="mb-6">
        <div className="flex justify-between items-center border-b border-gray-700 pb-4 mb-4">
          <h2 className="text-lg font-semibold text-white flex items-center">
            <FaIcon icon="gavel" className="mr-2 text-blue-400" />
            Manage Detection Rules
          </h2>
          <Button 
            variant="primary" 
            onClick={() => {
              setCurrentRule(null);
              setShowModal(true);
            }}
            icon="plus-circle"
          >
            Add New Rule
          </Button>
        </div>

        {/* Rule Table - Matches HTML structure */}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="text-left py-3 text-gray-400 font-medium">ID</th>
                <th className="text-left py-3 text-gray-400 font-medium">Rule Name</th>
                {/* ... other headers */}
              </tr>
            </thead>
            <tbody>
              {rules.map(rule => (
                <tr key={rule.id} className="border-b border-gray-800 hover:bg-gray-800/50">
                  <td className="py-3">{rule.id}</td>
                  <td className="py-3 font-medium">{rule.name}</td>
                  {/* ... other cells */}
                  <td className="py-3 text-right">
                    <div className="flex justify-end space-x-2">
                      <Button 
                        size="sm" 
                        variant="secondary" 
                        onClick={() => {
                          setCurrentRule(rule);
                          setShowModal(true);
                        }}
                        icon="edit"
                      />
                      <Button 
                        size="sm" 
                        variant={rule.status === 'active' ? 'warning' : 'positive'}
                        icon={rule.status === 'active' ? 'power-off' : 'play'}
                      />
                      <Button 
                        size="sm" 
                        variant="danger" 
                        icon="trash"
                      />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Modal - Matches HTML */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-lg shadow-xl w-full max-w-2xl border border-gray-700">
            <div className="flex justify-between items-center border-b border-gray-700 p-4">
              <h3 className="text-lg font-semibold text-white">
                {currentRule ? `Edit Rule ${currentRule.id}` : 'Add New Rule'}
              </h3>
              <button 
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-white text-xl"
              >
                &times;
              </button>
            </div>
            <div className="p-6">
              <form>
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-400 text-sm mb-1">Rule Name *</label>
                    <input
                      type="text"
                      defaultValue={currentRule?.name || ''}
                      className="w-full bg-gray-700 border border-gray-600 rounded px-3 py-2 text-white focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                  {/* ... other form fields */}
                </div>
                <div className="flex justify-end space-x-3 border-t border-gray-700 mt-6 pt-4">
                  <Button variant="secondary" onClick={() => setShowModal(false)}>
                    Cancel
                  </Button>
                  <Button variant="primary" type="submit" icon="save">
                    Save Rule
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default CaseView;
