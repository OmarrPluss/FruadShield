// src/pages/Cases/CaseOverview.jsx
import { useState } from 'react';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';

const CaseOverview = () => {
  const [overruleReason, setOverruleReason] = useState('');
  const [justificationNotes, setJustificationNotes] = useState('');
  const [investigationSteps, setInvestigationSteps] = useState({
    transactionHistory: true,
    linkedAccounts: false,
    contactedCustomer: true,
    merchantVerification: true,
    fraudPatterns: false,
  });

  const modelPrediction = 'FRAUD';
  const modelConfidence = '92%';

  const handleSubmitRuling = (isFraud) => {
    const finalDecision = isFraud ? "FRAUD" : "NOT FRAUD";
    const requiresJustification = (modelPrediction === "FRAUD" && !isFraud) || 
                               (modelPrediction === "NOT FRAUD" && isFraud);

    if (requiresJustification && justificationNotes.trim() === "") {
      alert("Justification notes are mandatory when overruling the model's prediction.");
      return;
    }
    if (requiresJustification && overruleReason === "") {
      alert("Please select a reason for overruling.");
      return;
    }

    const caseData = {
      caseId: "TXN-12345-FRD",
      modelPrediction: modelPrediction,
      modelConfidence: modelConfidence,
      overruleReason: overruleReason,
      finalJustification: justificationNotes.trim(),
      finalRuling: finalDecision,
    };

    console.log("Submitting Final Ruling:", caseData);
    alert(`Case TXN-12345-FRD has been ruled as ${finalDecision}`);
  };

  const handleSaveDraft = () => {
    const draftData = {
      caseId: "TXN-12345-FRD",
      overruleReasonDraft: overruleReason,
      justificationDraft: justificationNotes.trim()
    };
    console.log("Saving Draft:", draftData);
    alert("Draft saved successfully!");
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-white">Case Review: TXN-12345-FRD</h1>
        <p className="text-gray-400">Review the details below and provide your final ruling on this transaction.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Transaction Details Card */}
        <Card>
          <div className="flex items-center space-x-2 border-b border-gray-700 pb-4 mb-4">
            <i className="fas fa-receipt text-blue-400"></i>
            <h2 className="text-lg font-semibold text-white">Transaction Details</h2>
          </div>
          <div className="space-y-3">
            <DetailItem label="Transaction ID:" value="TXN-12345-FRD" />
            <DetailItem label="Amount:" value="1250.75 USD" valueClass="text-yellow-300" />
            <DetailItem label="Timestamp:" value="2024-05-14 10:32:15 UTC" />
            <DetailItem label="Merchant:" value="GlobalMegaMart Inc." />
            <DetailItem label="Customer ID:" value="CUST-A9876" />
            <DetailItem label="Payment Method:" value="Visa **** **** **** 5678" />
            <DetailItem label="IP Address:" value="123.45.67.89 (Country: Unknown)" />
            <DetailItem label="Device ID:" value="DEV-XYZ123-ABC" />
            <DetailItem 
              label="Transaction Risk Score:" 
              value="65 (Medium)" 
              valueClass="text-yellow-300 font-bold" 
            />
          </div>
        </Card>

        {/* Model Prediction Card */}
        <Card>
          <div className="flex items-center space-x-2 border-b border-gray-700 pb-4 mb-4">
            <i className="fas fa-brain text-blue-400"></i>
            <h2 className="text-lg font-semibold text-white">Model Prediction & Reasoning</h2>
          </div>
          <div className="space-y-3 mb-4">
            <DetailItem label="Model Prediction:" value="FRAUD" valueClass="text-pink-500 font-bold" />
            <DetailItem label="Confidence Score:" value="92%" valueClass="text-pink-500 font-bold" />
            <DetailItem label="Model Version:" value="v2.1.5 (XGBoost)" />
          </div>
          
          <div className="mt-4">
            <h4 className="text-gray-400 text-sm mb-2">Top Contributing Factors:</h4>
            <ul className="space-y-2">
              <FactorItem 
                icon="arrow-up" 
                text="High Transaction Amount ($1250.75)" 
                negative 
              />
              <FactorItem 
                icon="arrow-up" 
                text="IP Address Mismatch (Transaction Country vs. User Profile)" 
                negative 
              />
              <FactorItem 
                icon="arrow-down" 
                text="Historical Purchase from Merchant (2 previous)" 
                positive 
              />
              <FactorItem 
                icon="arrow-up" 
                text="Time Since Last Transaction (Very short: < 1 min)" 
                negative 
              />
            </ul>
            <a href="#" className="text-blue-400 text-xs mt-3 inline-block">
              View Full Model Explanation (SHAP/LIME)
            </a>
          </div>
        </Card>

        {/* Analyst Review Card - spans full width */}
        <Card className="lg:col-span-2">
          <div className="flex items-center space-x-2 border-b border-gray-700 pb-4 mb-4">
            <i className="fas fa-user-edit text-blue-400"></i>
            <h2 className="text-lg font-semibold text-white">Analyst Initial Review & Notes</h2>
          </div>
          <div className="space-y-3 mb-6">
            <DetailItem label="Analyst:" value="Jane Doe (JD007)" />
            <DetailItem label="Review Date:" value="2024-05-14 11:15:00 UTC" />
            <DetailItem 
              label="Initial Assessment:" 
              value="Potentially False Positive" 
              valueClass="text-yellow-300 font-bold" 
            />
          </div>
          
          <div className="mb-6">
            <label className="block text-gray-400 text-sm mb-2">Investigation Findings & Notes:</label>
            <textarea
              className="w-full bg-gray-800 border border-gray-700 rounded-md p-3 text-gray-200 text-sm font-mono"
              rows={6}
              defaultValue={`Customer called in, claims it was a legitimate purchase for a gift. Provided order confirmation matching merchant system.
IP mismatch might be due to VPN use, which customer confirmed they sometimes use for privacy.
Device ID is known. Previous purchases from this merchant were also high value around holidays.
Checking transaction patterns for similar amounts/merchants for this customer.
No other suspicious activity on the account recently.
Model flagged high due to amount and IP.`}
            />
          </div>
          
          <div>
            <label className="block text-gray-400 text-sm mb-2">Investigation Steps Taken:</label>
            <div className="space-y-2">
              <CheckboxItem 
                label="Checked customer transaction history" 
                checked={investigationSteps.transactionHistory}
                onChange={() => setInvestigationSteps({...investigationSteps, transactionHistory: !investigationSteps.transactionHistory})}
              />
              <CheckboxItem 
                label="Reviewed linked accounts/profiles" 
                checked={investigationSteps.linkedAccounts}
                onChange={() => setInvestigationSteps({...investigationSteps, linkedAccounts: !investigationSteps.linkedAccounts})}
              />
              <CheckboxItem 
                label="Contacted customer (or attempted)" 
                checked={investigationSteps.contactedCustomer}
                onChange={() => setInvestigationSteps({...investigationSteps, contactedCustomer: !investigationSteps.contactedCustomer})}
              />
              <CheckboxItem 
                label="Verified with merchant system" 
                checked={investigationSteps.merchantVerification}
                onChange={() => setInvestigationSteps({...investigationSteps, merchantVerification: !investigationSteps.merchantVerification})}
              />
              <CheckboxItem 
                label="Checked against known fraud patterns" 
                checked={investigationSteps.fraudPatterns}
                onChange={() => setInvestigationSteps({...investigationSteps, fraudPatterns: !investigationSteps.fraudPatterns})}
              />
            </div>
          </div>
        </Card>

        {/* Overrule Justification Card - spans full width */}
        <Card className="lg:col-span-2">
          <div className="flex items-center space-x-2 border-b border-gray-700 pb-4 mb-4">
            <i className="fas fa-balance-scale text-blue-400"></i>
            <h2 className="text-lg font-semibold text-white">Overrule Justification & Final Ruling</h2>
          </div>
          
          <div className="mb-6">
            <label className="block text-gray-400 text-sm mb-2">Reason for Overrule (if applicable):</label>
            <select
              className="w-full bg-gray-800 border border-gray-700 rounded-md p-2 text-gray-200"
              value={overruleReason}
              onChange={(e) => setOverruleReason(e.target.value)}
            >
              <option value="">Select a reason if overruling model...</option>
              <option value="known_behavior">Known Customer Behavior</option>
              <option value="fp_pattern">Matches Known False Positive Pattern</option>
              <option value="new_info">New Information/Evidence Acquired</option>
              <option value="model_error">Identified Model Error/Limitation</option>
              <option value="verified_legit">Verified Legitimacy with Customer/Merchant</option>
              <option value="other">Other (Specify in notes)</option>
            </select>
          </div>
          
          <div className="mb-6">
            <label className="block text-gray-400 text-sm mb-2">Final Justification Notes (Mandatory if overruling):</label>
            <textarea
              className="w-full bg-gray-800 border border-gray-700 rounded-md p-3 text-gray-200 text-sm font-mono"
              rows={4}
              placeholder="Clearly explain the reason for the final ruling, especially if it differs from the model's prediction or initial assessment. Provide specific evidence."
              value={justificationNotes}
              onChange={(e) => setJustificationNotes(e.target.value)}
            />
          </div>
          
          <div className="flex justify-end space-x-3 border-t border-gray-700 pt-4">
            <Button 
              variant="secondary" 
              onClick={handleSaveDraft}
              icon="save"
            >
              Save Draft
            </Button>
            <Button 
              variant="positive" 
              onClick={() => handleSubmitRuling(false)}
              icon="shield-check"
            >
              Confirm as NOT FRAUD
            </Button>
            <Button 
              variant="negative" 
              onClick={() => handleSubmitRuling(true)}
              icon="exclamation-triangle"
            >
              Confirm as FRAUD
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
};

// Helper components
const DetailItem = ({ label, value, valueClass = '' }) => (
  <div className="flex justify-between py-2 border-b border-gray-800 last:border-0">
    <span className="text-gray-400">{label}</span>
    <span className={`text-white font-medium ${valueClass}`}>{value}</span>
  </div>
);

const FactorItem = ({ icon, text, positive = false, negative = false }) => (
  <li className="flex items-center bg-gray-800 px-3 py-2 rounded text-sm">
    <i className={`fas fa-${icon} mr-2 ${positive ? 'text-green-400' : ''} ${negative ? 'text-pink-500' : ''}`}></i>
    {text}
  </li>
);

const CheckboxItem = ({ label, checked, onChange }) => (
  <label className="flex items-center space-x-2 cursor-pointer">
    <input 
      type="checkbox" 
      checked={checked}
      onChange={onChange}
      className="w-4 h-4 text-blue-400 bg-gray-800 border-gray-700 rounded focus:ring-blue-500"
    />
    <span className="text-gray-200 text-sm">{label}</span>
  </label>
);

export default CaseOverview;
