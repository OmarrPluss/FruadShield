import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from '../ui/card-model'
import { TabContainer, Tab } from '../ui/tab-container'
import { Dashboard, DashboardCard } from '../ui/dashboard-model'
import { ShapChart } from '../charts/ShapChart'
import { Microscope, ScatterChart, Percent, List } from 'lucide-react'

const XAITab = () => {
  const [activeModel, setActiveModel] = useState('model-1')

  const models = [
    { id: 'model-1', label: 'Model 1' },
    { id: 'model-2', label: 'Model 2' },
    { id: 'model-3', label: 'Model 3' },
    { id: 'model-4', label: 'Model 4' },
    { id: 'rca', label: 'RCA XAI' },
    { id: 'retrainer', label: 'Retrainer XAI' },
  ]

  const featureImpacts = [
    {
      feature: 'Transaction Amount',
      value: '$1,250.75',
      shapValue: '+0.35',
      impact: 'Increases Fraud Score',
      impactWidth: 70
    },
    {
      feature: 'V284',
      value: '0.012',
      shapValue: '+0.22',
      impact: 'Increases Fraud Score',
      impactWidth: 44
    },
    {
      feature: 'Time Since Last Txn',
      value: '3 hours',
      shapValue: '-0.15',
      impact: 'Decreases Fraud Score',
      impactWidth: 30
    },
    {
      feature: 'IP Geolocation Risk',
      value: 'High',
      shapValue: '+0.10',
      impact: 'Increases Fraud Score',
      impactWidth: 20
    },
    {
      feature: 'V14',
      value: '-0.58',
      shapValue: '-0.08',
      impact: 'Decreases Fraud Score',
      impactWidth: 16
    }
  ]

  return (
    <div>
      {/* Sub-tabs for different models */}
      <TabContainer className="mb-6 border-t border-border pt-5">
        {models.map((model) => (
          <Tab
            key={model.id}
            active={activeModel === model.id}
            onClick={() => setActiveModel(model.id)}
          >
            {model.label}
          </Tab>
        ))}
      </TabContainer>

      <h3 className="text-xl font-semibold mb-6 text-foreground">
        XAI Insights for {activeModel === 'model-1' ? 'Model 1: SentinelGuard Alpha' : `Model ${activeModel.split('-')[1]}`}
      </h3>

      {/* XAI Content */}
      <Dashboard>
        <DashboardCard span={2}>
          <Card>
            <CardHeader>
              <CardTitle>
                <ScatterChart className="h-5 w-5" />
                SHAP Values: Txn Amt vs V284
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ShapChart height={250} />
              <p className="text-xs text-muted-foreground mt-3">
                SHAP interaction plot showing how Transaction Amount and feature V284 jointly influence predictions.
              </p>
            </CardContent>
          </Card>
        </DashboardCard>

        <DashboardCard span={2}>
          <Card>
            <CardHeader>
              <CardTitle>
                <Percent className="h-5 w-5" />
                Prediction Probabilities Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center bg-muted/10 rounded">
                <div className="text-center">
                  <div className="text-4xl mb-2">📊</div>
                  <p className="text-sm text-muted-foreground">
                    Probability Distribution Chart
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    (Chart visualization would be rendered here)
                  </p>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-3">
                Distribution of prediction probabilities for recent samples, highlighting model confidence.
              </p>
            </CardContent>
          </Card>
        </DashboardCard>

        <DashboardCard span={4}>
          <Card>
            <CardHeader>
              <CardTitle>
                <List className="h-5 w-5" />
                Feature Value & SHAP Impact
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm mb-4">
                Top 5 features impacting a sample prediction (Placeholder Transaction ID: TXN123456789):
              </p>
              
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 px-4 text-muted-foreground font-medium">Feature Name</th>
                      <th className="text-left py-3 px-4 text-muted-foreground font-medium">Feature Value</th>
                      <th className="text-left py-3 px-4 text-muted-foreground font-medium">SHAP Value</th>
                      <th className="text-left py-3 px-4 text-muted-foreground font-medium">Impact Direction</th>
                    </tr>
                  </thead>
                  <tbody>
                    {featureImpacts.map((feature, index) => (
                      <tr key={index} className="border-b border-border/50 hover:bg-primary/5">
                        <td className="py-3 px-4 font-medium">{feature.feature}</td>
                        <td className="py-3 px-4">{feature.value}</td>
                        <td className="py-3 px-4 font-mono">{feature.shapValue}</td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-2">
                            <div 
                              className={`h-2 rounded ${
                                feature.shapValue.startsWith('+') 
                                  ? 'bg-green-500' 
                                  : 'bg-red-500'
                              }`}
                              style={{ width: `${feature.impactWidth}%` }}
                            />
                            <span className="text-xs">{feature.impact}</span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </DashboardCard>
      </Dashboard>
    </div>
  )
}

export { XAITab }

