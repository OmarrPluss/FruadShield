import { useState } from 'react'
import { Card, CardHeader, CardTitle, CardContent } from '../ui/card-model'
import { TabContainer, Tab } from '../ui/tab-container'
import { Dashboard, DashboardCard } from '../ui/dashboard-model'
import { ModelEvaluationChart } from '../charts/ModelEvaluationChart'
import { Info, BarChart3 } from 'lucide-react'

const OverviewTab = () => {
  const [activeModel, setActiveModel] = useState('model-1')

  const models = [
    { id: 'model-1', label: 'Model 1' },
    { id: 'model-2', label: 'Model 2' },
    { id: 'model-3', label: 'Model 3' },
    { id: 'model-4', label: 'Model 4' },
    { id: 'rca', label: 'RCA' },
    { id: 'retrainer', label: 'Retrainer' },
  ]

  const modelDetails = {
    'model-1': {
      name: 'SentinelGuard Alpha',
      version: '1.2.3',
      role: 'Primary transaction risk scoring',
      approach: 'XGBoost Classifier',
      lastTrained: '2025-05-01',
      inputFeatures: '120 (e.g., amount, location, time)',
      output: 'Fraud Score (0.0-1.0)',
      confusionMatrix: {
        tn: 14870,
        fp: 80,
        fn: 150,
        tp: 900
      }
    },
    'model-2': {
      name: 'BehaviorNet Pro',
      version: '2.1.0',
      role: 'User behavioral anomaly detection',
      approach: 'Recurrent Neural Network (LSTM)',
      lastTrained: '2025-04-20',
      inputFeatures: 'User session patterns, device info',
      output: 'Anomaly Score (0.0-1.0)',
      confusionMatrix: {
        tn: 13250,
        fp: 95,
        fn: 180,
        tp: 1475
      }
    },
    // Add more model details as needed
  }

  const currentModel = modelDetails[activeModel] || modelDetails['model-1']

  return (
    <div>
      {/* Sub-tabs for different models */}
      <TabContainer className="mb-6 border-t border-border pt-5">
        {models.map((model) => (
          <Tab
            key={model.id}
            active={activeModel === model.id}
            onClick={() => setActiveModel(model.id)}
          >
            {model.label}
          </Tab>
        ))}
      </TabContainer>

      {/* Model Overview Content */}
      <Dashboard>
        <DashboardCard span={2}>
          <Card>
            <CardHeader>
              <CardTitle>
                <Info className="h-10 w-10" />
                {currentModel.name} Details
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Name:</span>
                  <span className="font-medium">{currentModel.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Version:</span>
                  <span className="font-medium">{currentModel.version}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Role:</span>
                  <span className="font-medium text-sm">{currentModel.role}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Approach:</span>
                  <span className="font-medium">{currentModel.approach}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Last Trained:</span>
                  <span className="font-medium">{currentModel.lastTrained}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Input Features:</span>
                  <span className="font-medium text-sm">{currentModel.inputFeatures}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Output:</span>
                  <span className="font-medium">{currentModel.output}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </DashboardCard>

        <DashboardCard span={2}>
          <Card>
            <CardHeader>
              <CardTitle>
                <BarChart3 className="h-5 w-5" />
                Confusion Matrix
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4">
                <p className="text-sm font-medium mb-2">Text Representation:</p>
                <pre className="text-xs bg-muted/20 p-3 rounded text-muted-foreground">
{`Predicted   | Actual Non-Fraud | Actual Fraud
----------------------------------------------
Non-Fraud   | TN: ${currentModel.confusionMatrix.tn.toLocaleString()}        | FN: ${currentModel.confusionMatrix.fn}
Fraud       | FP: ${currentModel.confusionMatrix.fp}           | TP: ${currentModel.confusionMatrix.tp}`}
                </pre>
              </div>
              
              <div>
                <p className="text-sm font-medium mb-3">Visual Representation:</p>
                <div className="grid grid-cols-3 gap-2 text-sm">
                  <div></div>
                  <div className="text-center font-medium text-muted-foreground">Actual Non-Fraud</div>
                  <div className="text-center font-medium text-muted-foreground">Actual Fraud</div>
                  
                  <div className="font-medium text-muted-foreground">Predicted Non-Fraud</div>
                  <div className="text-center p-2 bg-green-500/20 rounded">
                    {currentModel.confusionMatrix.tn.toLocaleString()} <span className="text-xs">(TN)</span>
                  </div>
                  <div className="text-center p-2 bg-red-500/20 rounded">
                    {currentModel.confusionMatrix.fn} <span className="text-xs">(FN)</span>
                  </div>
                  
                  <div className="font-medium text-muted-foreground">Predicted Fraud</div>
                  <div className="text-center p-2 bg-red-500/20 rounded">
                    {currentModel.confusionMatrix.fp} <span className="text-xs">(FP)</span>
                  </div>
                  <div className="text-center p-2 bg-green-500/20 rounded">
                    {currentModel.confusionMatrix.tp} <span className="text-xs">(TP)</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </DashboardCard>

        <DashboardCard span={4}>
          <Card>
            <CardHeader>
              <CardTitle>
                <BarChart3 className="h-5 w-5" />
                Model Evaluation
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ModelEvaluationChart height={250} />
            </CardContent>
          </Card>
        </DashboardCard>
      </Dashboard>
    </div>
  )
}

export { OverviewTab }

