import React from 'react';

const StatusDisplay = ({ status, text }) => {
  const getStatusClass = () => {
    switch (status) {
      case 'Passed':
      case 'Healthy':
      case 'Normal':
        return 'status-green';
      case 'Warning':
      case 'Degraded':
        return 'status-yellow';
      case 'Failed':
      case 'Critical':
        return 'status-red';
      default:
        return '';
    }
  };
  
  return (
    <span>
      <span className={`status-indicator ${getStatusClass()}`}></span>
      {text || status}
    </span>
  );
};

export default StatusDisplay;
