import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const Card = ({ children, title, icon, span = 4, actions = [], expandable = false }) => {
  const [expanded, setExpanded] = React.useState(false);
  
  const handleExpand = () => {
    setExpanded(!expanded);
  };
  
  const getSpanClass = () => {
    switch (span) {
      case 4:
        return 'col-span-4';
      case 6:
        return 'col-span-6';
      case 8:
        return 'col-span-8';
      case 12:
        return 'col-span-12';
      default:
        return 'col-span-4';
    }
  };
  
  return (
    <div className={`card ${getSpanClass()} ${expanded ? 'fixed top-20 left-1/2 transform -translate-x-1/2 w-[90%] h-[80vh] z-50 overflow-y-auto' : ''}`}>
      <div className="flex justify-between items-center mb-5 pb-3 border-b border-divider-color">
        <div className="flex items-center gap-2 text-lg font-semibold text-text-light">
          {icon && <FontAwesomeIcon icon={icon} className="text-primary-accent" />}
          <span>{title}</span>
        </div>
        
        <div className="flex gap-2">
          {actions.map((action, index) => (
            <button 
              key={index}
              className="bg-transparent border-none text-text-muted cursor-pointer w-6 h-6 flex items-center justify-center rounded hover:bg-white hover:bg-opacity-10 hover:text-text-light transition-all duration-200"
              onClick={action.onClick}
            >
              <FontAwesomeIcon icon={action.icon} />
            </button>
          ))}
          
          {expandable && (
            <button 
              className="bg-transparent border-none text-text-muted cursor-pointer w-6 h-6 flex items-center justify-center rounded hover:bg-white hover:bg-opacity-10 hover:text-text-light transition-all duration-200"
              onClick={handleExpand}
            >
              <FontAwesomeIcon icon={expanded ? 'compress' : 'expand'} />
            </button>
          )}
        </div>
      </div>
      
      {children}
      
      {expanded && (
        <div className="fixed top-0 left-0 right-0 bottom-0 bg-black bg-opacity-70 z-40" onClick={handleExpand}></div>
      )}
    </div>
  );
};

export default Card;
