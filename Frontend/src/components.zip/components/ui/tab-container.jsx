import { cn } from "../../lib/utils"

const TabContainer = ({ className, children, ...props }) => (
  <div
    className={cn(
      "flex border-b border-border mb-6",
      className
    )}
    {...props}
  >
    {children}
  </div>
)

const Tab = ({ className, active = false, children, onClick, ...props }) => (
  <button
    className={cn(
      "px-5 py-3 cursor-pointer font-medium text-muted-foreground relative transition-all duration-300 inline-flex items-center gap-2 hover:text-foreground hover:bg-primary/5",
      active && "text-primary",
      active && "after:content-[''] after:absolute after:bottom-[-1px] after:left-0 after:right-0 after:h-0.5 after:bg-primary",
      className
    )}
    onClick={onClick}
    {...props}
  >
    {children}
  </button>
)

export { TabContainer, Tab }

