import { cn } from "../../lib/utils"

const statusVariants = {
  active: "bg-green-500",
  inactive: "bg-red-500",
  warning: "bg-yellow-500",
  pending: "bg-blue-500",
}

const StatusDisplay = ({ className, status = "active", label, ...props }) => (
  <div className={cn("flex items-center gap-2", className)} {...props}>
    <div
      className={cn(
        "w-3 h-3 rounded-full",
        statusVariants[status]
      )}
    />
    <span className="text-sm font-medium">{label}</span>
  </div>
)

export { StatusDisplay }

