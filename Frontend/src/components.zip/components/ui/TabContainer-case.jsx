import React, { useState } from 'react';

const TabContainer = ({ children, defaultTab = 0, className = '' }) => {
  const [activeTab, setActiveTab] = useState(defaultTab);

  const tabs = React.Children.toArray(children);

  return (
    <div className={`${className}`}>
      <div className="flex border-b border-[var(--divider-color)] mb-6">
        {tabs.map((tab, index) => (
          <button
            key={index}
            className={`px-6 py-3 font-medium text-sm transition-all duration-200 border-b-2 ${
              activeTab === index
                ? 'text-[var(--primary-accent)] border-[var(--primary-accent)]'
                : 'text-[var(--text-muted)] border-transparent hover:text-[var(--text-light)]'
            }`}
            onClick={() => setActiveTab(index)}
          >
            {tab.props.label}
          </button>
        ))}
      </div>
      <div>
        {tabs[activeTab]}
      </div>
    </div>
  );
};

const TabPanel = ({ children, label, ...props }) => {
  return <div {...props}>{children}</div>;
};

export { TabContainer, TabPanel };

